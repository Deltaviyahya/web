-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 27 Agu 2018 pada 18.17
-- Versi server: 10.1.31-MariaDB
-- Versi PHP: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_login`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `nip` varchar(15) NOT NULL,
  `nama` varchar(90) DEFAULT NULL,
  `pass` varchar(40) DEFAULT NULL,
  `level` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`nip`, `nama`, `pass`, `level`) VALUES
('100001', 'Deltavi', 'qwerty', 1),
('100003', 'HANA', 'deltav', 1),
('100041', 'deltus', 'kadalsange', 1),
('1001', 'mantap', 'kadalsange', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `datarouter`
--

CREATE TABLE `datarouter` (
  `id` int(25) NOT NULL,
  `update_at` timestamp(6) NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `platform` varchar(255) NOT NULL,
  `board_name` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `architecture_name` varchar(255) NOT NULL,
  `cpu` varchar(255) NOT NULL,
  `cpu_frequency` varchar(255) NOT NULL,
  `cpu_count` varchar(255) NOT NULL,
  `uptime` varchar(255) NOT NULL,
  `cpu_load` varchar(255) NOT NULL,
  `total_memory` varchar(255) NOT NULL,
  `free_memory` varchar(255) NOT NULL,
  `total_hdd_space` varchar(255) NOT NULL,
  `free_hdd_space` varchar(255) NOT NULL,
  `write_sect_total` varchar(255) NOT NULL,
  `write_sect_since_reboot` varchar(255) NOT NULL,
  `bad_blocks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `datarouter`
--

INSERT INTO `datarouter` (`id`, `update_at`, `platform`, `board_name`, `version`, `architecture_name`, `cpu`, `cpu_frequency`, `cpu_count`, `uptime`, `cpu_load`, `total_memory`, `free_memory`, `total_hdd_space`, `free_hdd_space`, `write_sect_total`, `write_sect_since_reboot`, `bad_blocks`) VALUES
(1, '2018-08-27 16:12:51.104762', 'MikroTik', 'hAP', '6.40.4', 'smips', 'MIPS', '650', '1', '2d6h59m10s', '0', '33554432', '8044544', '16777216', '8040448', '72106', '42100', '0');

-- --------------------------------------------------------

--
-- Struktur dari tabel `interface`
--

CREATE TABLE `interface` (
  `id` int(25) NOT NULL,
  `name` varchar(255) NOT NULL,
  `defaultname` varchar(255) NOT NULL,
  `macaddress` varchar(255) NOT NULL,
  `lastlinkdowntime` varchar(255) NOT NULL,
  `lastlinkuptime` varchar(255) NOT NULL,
  `rxbyte` varchar(255) NOT NULL,
  `txbyte` varchar(255) NOT NULL,
  `rxpacket` varchar(255) NOT NULL,
  `txpacket` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `interface`
--

INSERT INTO `interface` (`id`, `name`, `defaultname`, `macaddress`, `lastlinkdowntime`, `lastlinkuptime`, `rxbyte`, `txbyte`, `rxpacket`, `txpacket`) VALUES
(1, 'ether1_LOCAL_IN', 'ether1', 'CC:2D:E0:AD:CE:D9', 'aug/27/2018', 'aug/27/2018', '1577126467', '228399261', '1720590', '1472633'),
(2, 'erwe', 'werwe', 'rewweg', 'wergqwr', 'grgqrg', 'qrgqr', 'gqrgqqr', 'qgr', 'rqgreg'),
(3, 'sgsegre', 'grergerg', 'regerg', 'ergerg', 'ewrgwergwe', 'rgwergwer', 'grwegreg', 'wregwre', 'wregreg'),
(4, 'ewfrwg', 'rger', 'gerger', 'gerge', 'rgergreg', 'grerg', 'regerg', 'regerger', 'eererg'),
(5, 'rgerg', 'erge', 'rwreger', 'gerger', 'gergreger', 'ergerger', 'gerger', 'gregerg', 'ergereg'),
(6, 'ether1_LOCAL_IN', 'ether1', 'CC:2D:E0:AD:CE:D9', 'aug/27/2018', 'aug/27/2018', '1575529022', '224712832', '1714268', '1466225');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`nip`);

--
-- Indeks untuk tabel `datarouter`
--
ALTER TABLE `datarouter`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `interface`
--
ALTER TABLE `interface`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `datarouter`
--
ALTER TABLE `datarouter`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `interface`
--
ALTER TABLE `interface`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
