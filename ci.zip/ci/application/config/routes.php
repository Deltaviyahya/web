<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'welcome';
/*$route['monitoring'] = 'page/v_monitoring';*/
/*$route['page'] = 'page/home';*/
/*$route['auth'] = 'login/auth';*/
$route['listadmin'] = 'C_admin';
$route['logout'] = 'login/logout';
$route['monitoring'] = 'C_monitoring';
$route['monitoringinterface'] = 'C_monitoring_interface';
$route['tambahadmin'] = 'C_admin/simpan_admin';
$route['editadmin'] ='C_admin/edit_admin';
$route['hapusadmin'] ='C_admin/hapus_admin';
$route['server'] = 'page/v_server';

$route['404_override'] = 'ControllerError';
$route['translate_uri_dashes'] = FALSE;
