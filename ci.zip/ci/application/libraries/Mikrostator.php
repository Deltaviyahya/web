<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
require_once 'routeros_api.class.php';

class Mikrostator Extends routeros_api {

    private $mikrotik_host = "192.168.88.1";
    private $mikrotik_port = "8728";
    private $mikrotik_username = "admin";
    private $mikrotik_password = "";
    
    //put your code here
    public function __construct($data) {
        //...
    }
    
    function konek($data){
        $this->mikrotik_host = $data['mikrotik_host'];
        $this->mikrotik_port = $data['mikrotik_port'];
        $this->mikrotik_username = $data['mikrotik_username'];
        $this->mikrotik_password = $data['mikrotik_password'];
        return $this->connect2($this->mikrotik_host, $this->mikrotik_username, $this->mikrotik_password, $this->mikrotik_port);        
    }

}

?>
