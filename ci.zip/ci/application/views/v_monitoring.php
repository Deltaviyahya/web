<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title> Monitoring </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="<?php echo base_url().'assets/css/bootstrap.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/css/jquery.dataTables.css'?>" rel="stylesheet">
    </head>
    <body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
      <?php $this->load->view('sub_home');?>x
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a><span class="glyphicon glyphicon-user"></span> Login as: <?php echo $this->session->userdata('ses_nama') ?></a></li>
      <li><a href="<?php echo base_url().'logout'?>"><span class="glyphicon glyphicon-log-in"></span> LogOut</a></li>
    </ul>
  </div>
</nav>

<div class="container">
  <h1>Monitoring<small> device</small></h1>
    <table class="table table-bordered table-striped " id="mydata" >
      <thead>
        <tr >
            <td>No</td>
            <td>Update At (yyyy/mm/dd) (hh/mm/ss/ms)</td>
            <td>Platform </td>
            <td>Board Name </td>
            <td>Ros Version </td>
            <td>Architecture Name</td>
            <td>Cpu </td>
            <td>CPU frequency </td>
            <td>available cores of CPU core(s)</td>
            <td>Uptime (hh/mm/ss)</td>
            <td>Cpu Load is</td>
            <td>Total Memory (byte)</td>
        </tr>
      </thead>
    <tbody>
      <div id = "#value">
      <?php
        foreach($datarouter as $i):                               
      ?>
      <tr>
                <td><?php echo $i->id; ?></td>
                <td><?php echo $i->update_at; ?></td>
                <td><?php echo $i->platform;?></td>
                <td><?php echo $i->board_name;?></td>
                <td><?php echo $i->version;?></td>
                <td><?php echo $i->architecture_name;?></td>
                <td><?php echo $i->cpu;?></td>
                <td><?php echo $i->cpu_frequency;?></td>
                <td><?php echo $i->cpu_count ;?></td>
                <td><?php echo $i->uptime ;?></td>
                <td><?php echo $i->cpu_load;?></td>
                <td><?php echo $i->total_memory;?></td>
        <?php endforeach; ?>
        </div>
      </tr>
    </tbody>
</table>
    <table class="table table-bordered table-striped " id="mydata" >
      <thead>
        <tr >
            <td>No</td>
            <td>Update At (yyyy/mm/dd) (hh/mm/ss/ms)</td>
            <td>Platform </td>
            <td>Free Memory </td>
            <td>Total Hdd Space </td>
            <td>Free Hdd space </td>
            <td>Sector Write total </td>
            <td>Sector Write Since Reboot </td>
            <td>Sector bad Blocks </td>
        </tr>
      </thead>
    <tbody>
      <div id = "#value">
      <?php
        foreach($datarouter as $i):                               
      ?>
      <tr>
                <td><?php echo $i->id; ?></td>
                <td><?php echo $i->update_at; ?></td>
                <td><?php echo $i->platform;?></td>
                <td><?php echo $i->free_memory ;?></td>
                <td><?php echo $i->total_hdd_space;?></td>
                <td><?php echo $i->free_hdd_space;?></td>
                <td><?php echo $i->write_sect_total;?></td>
                <td><?php echo $i->write_sect_since_reboot;?></td>
                <td><?php echo $i->bad_blocks;?></td>
        <?php endforeach; ?>
        </div>
      </tr>
    </tbody>
             </div>
           </div>
<script src="<?php echo base_url().'assets/js/jquery-2.2.4.min.js'?>"></script>
<script src="<?php echo base_url().'assets/js/bootstrap.js'?>"></script>
<script src="<?php echo base_url().'assets/js/jquery.dataTables.min.js'?>"></script>
<script src="<?php echo base_url().'assets/js/moment.js'?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
  $(document).ready(function(){
    $('#mydata').DataTable();
  });
</script>
<script>
    var timer = null;
    function auto_reload()
    {
      url.location = 'server/update';
    }
    
    <!-- Reload page every 10 seconds. -->
       <body onload="timer = setTimeout('auto_reload()',1000);">
</script>
    </body>
</html>