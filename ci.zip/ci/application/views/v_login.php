<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Monitoring</title>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <!-- Styles -->
        <link rel = "stylesheet" type = "text/css" href = "assets/css/style.css">
        <link rel = "stylesheet" type = "text/css" href = "assets/css/style_Login.css">
    </head>
    <body>
        <!-- <div class="flex-center position-ref full-height">
          <div class="title"><p>[ MASIH ] COMMING SOON</p>
          </div>
        </div> -->
                <div class="flex-center position-ref full-height">
                <div class="container">
                    <form class="form-signin" action="<?php echo base_url().'login/auth'?>" method="post">
                      <h2 class="form-signin-heading">Please sign in</h2>
                      <?php echo $this->session->flashdata('msg');?>
                      <label for="username" class="sr-only"></label>
                      <input type="text" id="username" name="username" class="form-control" placeholder="Username" required autofocus>
                      <label for="password" class="sr-only"></label>
                      <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
                      <div class="checkbox">
                        <label>
                          <input type="checkbox" value="remember-me"> Remember me
                        </label>
                      </div>
                      <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
                    </form>
                  </div>
                  </div> <!-- /container -->
                    <div class="content">
                     <!-- FOOTER -->
                     <p> @copyright deltaviyahya 2018</p>
                     <p> COMMING SOON</p>
                </div>
                </div>
    </body>
</html>