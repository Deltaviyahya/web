<!--Akses Menu Untuk subAdmin-->
<?php if($this->session->userdata('akses')=='1'):?>
  <li class="active"><a href="<?php echo base_url().'page'?>">Dashboard</a></li>
  <li><a href="<?php echo base_url().'monitoring'?>">Monitoring Device</a></li>
  <li><a href="<?php echo base_url().'monitoringinterface'?>">Monitoring Interface</a></li>
  <li><a href="<?php echo base_url().'listadmin'?>">List Admin</a></li>
  <li><a href="<?php echo base_url().'server'?>">Server</a></li>
  <!--Akses Menu Untuk admin-->
<?php else:?>
  <li><a href="<?php echo base_url().'page'?>">Dashboard</a></li>
  <li><a href="<?php echo base_url().'monitoring'?>">Monitoring Device</a></li>
  <li><a href="<?php echo base_url().'monitoringinterface'?>">Monitoring Interface</a></li>
<?php endif;?>