<br><br>
<?php 
echo "ini halaman footer";
 ?>