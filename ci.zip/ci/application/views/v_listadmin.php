<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Daftar Admin</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="<?php echo base_url().'assets/css/bootstrap.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/css/jquery.dataTables.min.css'?>" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
      <?php $this->load->view('sub_home');?>x
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> Login as: <?php echo $this->session->userdata('ses_nama') ?></a></li>
      <li><a href="<?php echo base_url().'logout'?>"><span class="glyphicon glyphicon-log-in"></span> LogOut</a></li>
    </ul>
  </div>
</nav>        
<div class="container">
  <h1>admin <small>list admin!</small><div class="pull-right"></div>       
    </h1>
  <table class="table table-bordered table-striped" id="mydata">
    <thead>
      <tr>
        <td>NO</td>
        <td>NIP</td>
        <td>NAMA</td>
        <td>PASSWORD</td>
        <td>LEVEL</td>
        <td><a class="btn btn-sm btn-success" data-toggle="modal" data-target="#modal_add_new"> Add New</a></td>
      </tr>
    </thead>
    <tbody>
      <?php 
      $no=1;
        foreach($listadmin->result_array() as $i):
                    $nip=$i['nip'];
                    $nama=$i['nama'];
                    $pass=$i['pass'];
                    $level=$i['level'];

      ?>
      <tr>
        <td><?php echo $no++; ?></td>
        <td><?php echo $nip;?></td>
        <td><?php echo $nama;?></td>
        <td><?php echo $pass;?></td>
        <td><?php echo $level; ?></td>
        <td><a class="btn btn-xs btn-info" data-toggle="modal" data-target="#modal_edit<?php echo $nip;?>"> Edit</a>
        <a class="btn btn-xs btn-danger" data-toggle="modal" data-target="#modal_hapus<?php echo $nip;?>"> Hapus</a></td>
      </tr>
      <?php endforeach;?>
    </tbody>
  </table>
</div>
<!-- ============ MODAL ADD ADMIN =============== -->
        <div class="modal fade" id="modal_add_new" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                <h3 class="modal-title" id="myModalLabel">Tambah Admin</h3>
            </div>
            <form class="form-horizontal" method="post" action="<?php echo base_url().'tambahadmin'?>">
                <div class="modal-body">
 
                    <div class="form-group">
                        <label class="control-label col-xs-3" >NIP</label>
                        <div class="col-xs-8">
                            <input name="nip" class="form-control" type="text" placeholder="nip" required>
                        </div>
                    </div>
 
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Nama</label>
                        <div class="col-xs-8">
                            <input name="nama" class="form-control" type="text" placeholder="nama" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-xs-3" >Level</label>
                        <div class="col-xs-8">
                             <select name="level" class="form-control" required>
                                <option value="">-PILIH-</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                             </select>
                        </div>
                    </div>
 
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Password</label>
                        <div class="col-xs-8">
                            <input name="pass" class="form-control" type="text" placeholder="password" required>
                        </div>
                    </div>
 
                </div>
 
                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                    <button class="btn btn-info">Simpan</button>
                </div>
            </form>
            </div>
            </div>
        </div>
        <!--END MODAL ADD ADMIN-->
         <!-- ============ MODAL EDIT ADMIN =============== -->
   <?php
        foreach($listadmin->result_array() as $i):
                    $nip=$i['nip'];
                    $nama=$i['nama'];
                    $pass=$i['pass'];
                    $level=$i['level'];
        ?>
        <div class="modal fade" id="modal_edit<?php echo $nip;?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                <h3 class="modal-title" id="myModalLabel">Edit Admin</h3>
            </div>
            <form class="form-horizontal" method="post" action="<?php echo base_url().'editadmin'?>">
                <div class="modal-body">
 
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Nip</label>
                        <div class="col-xs-8">
                            <input name="nip" value="<?php echo $nip;?>" class="form-control" type="text" placeholder="nip" readonly>
                        </div>
                    </div>
 
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Nama</label>
                        <div class="col-xs-8">
                            <input name="nama" value="<?php echo $nama;?>" class="form-control" type="text" placeholder="nama..." required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Password</label>
                        <div class="col-xs-8">
                            <input name="pass" value="<?php echo $pass;?>" class="form-control" type="text" placeholder="password..." required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Level</label>
                        <div class="col-xs-8">
                          <select name="level" value"<?php echo "$level"; ?>" class="form-control" required>
                                <option value="">-PILIH-</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                             </select>
                        </div>
                    </div>
 
                </div>
 
                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                    <button class="btn btn-info">Update</button>
                </div>
            </form>
            </div>
            </div>
        </div>
 
    <?php endforeach;?>
    <!-- ============ MODAL HAPUS ADMIN =============== -->
   <?php
        foreach($listadmin->result_array() as $i):
                    $nip=$i['nip'];
                    $nama=$i['nama'];
                    $pass=$i['pass'];
                    $level=$i['level'];
        ?>
        <div class="modal fade" id="modal_hapus<?php echo $nip;?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                <h3 class="modal-title" id="myModalLabel">Hapus Admin</h3>
            </div>
            <form class="form-horizontal" method="post" action="<?php echo base_url().'hapusadmin'?>">
                <div class="modal-body">
                    <p>Anda yakin mau menghapus </p>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Nip</label>
                        <div class="col-xs-8">
                            <input name="nip" value="<?php echo $nip;?>" class="form-control"readonly>
                        </div>
                    </div>
 
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Nama</label>
                        <div class="col-xs-8">
                            <input name="nama" value="<?php echo $nama;?>" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Level</label>
                        <div class="col-xs-8">
                            <input name="level" value="<?php echo $level;?>" class="form-control" readonly>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="nip" value="<?php echo $nip;?>">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                    <button class="btn btn-danger">Hapus</button>
                </div>
            </form>
            </div>
            </div>
        </div>
    <?php endforeach;?>

<script src="<?php echo base_url().'assets/js/jquery-2.2.4.min.js'?>"></script>
<script src="<?php echo base_url().'assets/js/bootstrap.js'?>"></script>
<script src="<?php echo base_url().'assets/js/jquery.dataTables.min.js'?>"></script>
<script src="<?php echo base_url().'assets/js/moment.js'?>"></script>
<script>
  $(document).ready(function(){
    $('#mydata').DataTable();
  });
</script>

</body>
</html>