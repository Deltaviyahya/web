<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title> Monitoring iface </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="<?php echo base_url().'assets/css/bootstrap.css'?>" rel="stylesheet">
    <link href="<?php echo base_url().'assets/css/jquery.dataTables.min.css'?>" rel="stylesheet">
    </head>
    <body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
      <?php $this->load->view('sub_home');?>x
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> Login as: <?php echo $this->session->userdata('ses_nama') ?></a></li>
      <li><a href="<?php echo base_url().'logout'?>"><span class="glyphicon glyphicon-log-in"></span> LogOut</a></li>
    </ul>
  </div>
</nav>        
      <div class="container">
  <h1>Monitoring<small> interface</small></h1>
  <table class="table table-bordered table-striped" id="mydata" >
    <thead>
      <tr >
            <td>ID</td>
            <td>nama</td>
            <td>defaultname</td>
            <td>macaddress</td>
            <td>lastlinkdowntime</td>
            <td>lastlinkuptime</td>
            <td>rxbyte</td>
            <td>txbyte</td>
            <td>rxpacket</td>
            <td>txpacket</td>
      </tr>
    </thead>
    <tbody>
      <?php
        foreach($datainterface as $i):
              $id=$i['id'];
              $nama=$i['name'];
              $defaultname=$i['defaultname'];
              $macaddress=$i['macaddress'];
              $lastlinkdowntime=$i['lastlinkdowntime'];
              $lastlinkuptime=$i['lastlinkuptime'];
              $rxbyte=$i['rxbyte'];
              $txbyte=$i['txbyte'];
              $rxpacket=$i['rxpacket'];
              $txpacket=$i['txpacket'];                               
      ?>
      <tr>
                <td><?php echo $id; ?></td>
                <td><?php echo $nama;?></td>
                <td><?php echo $defaultname;?></td>
                <td><?php echo $macaddress;?></td>
                <td><?php echo $lastlinkdowntime;?></td>
                <td><?php echo $lastlinkuptime;?></td>
                <td><?php echo $rxbyte;?></td>
                <td><?php echo $txbyte;?></td>
                <td><?php echo $rxpacket;?></td>
                <td><?php echo $txpacket;?></td>
        <?php endforeach; ?>
      </tr>
    </tbody>
  </table>
     <!-- FOOTER -->
                 <div class="container" style="text-align: center;">
                 <p> @copyright deltaviyahya 2018</p>
                 <p> COMMING SOON</p></div>

    
             </div>
           </div>
<script src="<?php echo base_url().'assets/js/jquery-2.2.4.min.js'?>"></script>
<script src="<?php echo base_url().'assets/js/bootstrap.js'?>"></script>
<script src="<?php echo base_url().'assets/js/jquery.dataTables.min.js'?>"></script>
<script src="<?php echo base_url().'assets/js/moment.js'?>"></script>
<script>
  $(document).ready(function(){
    $('#mydata').DataTable();
  });
</script>
    </body>
</html>