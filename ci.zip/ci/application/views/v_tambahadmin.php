<!DOCTYPE html>
<html>
<head>
	<title>tambah admin</title>
</head>
<body>
	<?php $this->load->view('sub_home');?>
      <?php echo $this->session->userdata('ses_nama');?> <!--Include menu-->
      <h1>Tambah admin</h1>
      <form class="form-tambah" action="<?php echo base_url().'C_admin/tambah_aksi'?>" method="post">
      	<table style="margin: 20px auto">
      		<tr>
				<td>Nama</td>
				<td><input type="text" name="nip"></td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td><input type="text" name="nama"></td>
			</tr>
			<tr>
				<td>Pekerjaan</td>
				<td><input type="text" name="password"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Tambah"></td>
			</tr>
      	</table>

      	

      </form>

</body>
</html>