<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
      <title> Server </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script type=" text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.0/jquery.min.js"></script>
    <script type="text/javascript">
        var auto_refresh = setInterval(
            function () {
                $('#mydata').load('server/update').fadeIn("fast");
            }, 1000); // refresh every 1 second
    </script>
<link href="<?php echo base_url().'assets/css/bootstrap.css'?>" rel="stylesheet">
<link href="<?php echo base_url().'assets/css/jquery.dataTables.min.css'?>" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-inverse">
   <div class="container-fluid">
    <ul class="nav navbar-nav">
      <?php $this->load->view('sub_home');?>x
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> Login as: <?php echo $this->session->userdata('ses_nama') ?></a></li>
      <li><a href="<?php echo base_url().'logout'?>"><span class="glyphicon glyphicon-log-in"></span> LogOut</a></li>
    </ul>
  </div>
</nav>        
<div class="container">
<?php
 
            require('routeros_api.class.php');
            $API = new routeros_api();
            $API->debug = false;

            if($API->connect('192.168.88.1', 'admin', '')){
              echo "<br>Status Koneksi : Berhasil<br>";
              // jumlah client connext//
               $API->write('/interface/wireless/registration-table/print',false);
               $API->write('=count-only=');
                  $READ = $API->read(false);
                  $ARRAY0 = $API->parse_response($READ);
                echo "Number of connected clients : " . substr($READ[1],5)."<br>"; 
              //detail router //

                $ARRAY1 = $API->comm("/system/resource/print");
                $platform = $ARRAY1['0'];
                $boardname = $ARRAY1['0'];
                $version = $ARRAY1['0'];
                $architecturename = $ARRAY1['0'];
                $cpu = $ARRAY1['0'];
                $cpufrequency = $ARRAY1['0'];
                $cpucount = $ARRAY1['0'];
                $uptime = $ARRAY1['0'];
                $cpuload = $ARRAY1['0'];
                $totalmemory = $ARRAY1['0'];
                $freememory = $ARRAY1['0'];
                $totalhddspace = $ARRAY1['0'];
                $freehddspace = $ARRAY1['0'];
                $writesecttotal = $ARRAY1['0'];
                $writesectsincereboot = $ARRAY1['0'];
                $badblocks = $ARRAY1['0'];
              //print all intercace
              echo "<br>";
              //interface 1
                $ARRAY2=$API->comm('/interface/getall');
                $nama = $ARRAY2['0'];
                $defaultname = $ARRAY2['0'];
                $macaddress = $ARRAY2['0'];
                $lastlinkdowntime = $ARRAY2['0'];
                $lastlinkuptime = $ARRAY2['0'];
                $rxbyte = $ARRAY2['0'];
                $txbyte = $ARRAY2['0'];
                $rxpacket = $ARRAY2['0'];
                $txpacket = $ARRAY2['0'];

                $nama1 = $ARRAY2['1'];
                $defaultname1 = $ARRAY2['1'];
                $macaddress1 = $ARRAY2['1'];
                $lastlinkdowntime1 = $ARRAY2['1'];
                $lastlinkuptime1 = $ARRAY2['1'];
                $rxbyte1 = $ARRAY2['1'];
                $txbyte1 = $ARRAY2['1'];
                $rxpacket1 = $ARRAY2['1'];
                $txpacket1 = $ARRAY2['1'];
                echo "<br>";
                //intercafe3
                $nama2 = $ARRAY2['2'];
                $defaultname2 = $ARRAY2['2'];
                $macaddress2 = $ARRAY2['2'];
                $lastlinkdowntime2 = $ARRAY2['2'];
                $lastlinkuptime2 = $ARRAY2['2'];
                $rxbyte2 = $ARRAY2['2'];
                $txbyte2 = $ARRAY2['2'];
                $rxpacket2 = $ARRAY2['2'];
                $txpacket2 = $ARRAY2['2'];
                //interface4
                $nama3 = $ARRAY2['3'];
                $defaultname3 = $ARRAY2['3'];
                $macaddress3 = $ARRAY2['3'];
                $lastlinkdowntime3 = $ARRAY2['3'];
                $lastlinkuptime3 = $ARRAY2['3'];
                $rxbyte3 = $ARRAY2['3'];
                $txbyte3 = $ARRAY2['3'];
                $rxpacket3 = $ARRAY2['3'];
                $txpacket3 = $ARRAY2['3'];
                echo "<br>";
                //interface5
                $nama4 = $ARRAY2['4'];
                $defaultname4 = $ARRAY2['4'];
                $macaddress4 = $ARRAY2['4'];
                $lastlinkdowntime4 = $ARRAY2['4'];
                $lastlinkuptime4 = $ARRAY2['4'];
                $rxbyte4 = $ARRAY2['4'];
                $txbyte4 = $ARRAY2['4'];
                $rxpacket4 = $ARRAY2['4'];
                $txpacket4 = $ARRAY2['4'];
                echo "<br>";
              
        
             }
           
 ?>

            <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
            </div>
            <form class="form-horizontal" method="post" action="<?php echo base_url().'server/update'?>">
              <div style="text-align: center;">Device</div>
              <div class="form-group">
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-info">Update</button>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-xs-3" >Platform</label>
                        <div class="col-xs-8">
                            <input readonly name="platform" class="form-control" value=<?php echo htmlspecialchars($platform['platform']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >BOARD NAME</label>
                        <div class="col-xs-8">
                            <input readonly name="board_name" class="form-control" value=<?php echo htmlspecialchars($boardname['board-name']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Version</label>
                        <div class="col-xs-8">
                            <input readonly name="version" class="form-control" value=<?php echo htmlspecialchars($version['version']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label readonly class="control-label col-xs-3" >Architecture Name</label>
                        <div class="col-xs-8">
                            <input readonly name="architecture_name" class="form-control" value=<?php echo htmlspecialchars($architecturename['architecture-name']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label readonly class="control-label col-xs-3" >CPU</label>
                        <div class="col-xs-8">
                            <input readonly name="cpu" class="form-control" value=<?php echo htmlspecialchars($cpu['cpu']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >CPU Freqwensi ( Mhz )</label>
                        <div class="col-xs-8">
                            <input readonly name="cpu_frequency" class="form-control" value=<?php echo htmlspecialchars($cpufrequency['cpu-frequency']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >CPU Count - Core(s) </label>
                        <div class="col-xs-8">
                            <input readonly name="cpu_count" class="form-control" value=<?php echo htmlspecialchars($cpucount['cpu-count']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Up Time</label>
                        <div class="col-xs-8">
                            <input readonly name="uptime" class="form-control" value=<?php echo htmlspecialchars($uptime['uptime']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >CPU Load - % </label>
                        <div class="col-xs-8">
                            <input readonly name="cpu_load" class="form-control" value=<?php echo htmlspecialchars($cpuload['cpu-load']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Total Memory - Kb</label>
                        <div class="col-xs-8">
                            <input readonly name="total_memory" class="form-control" value=<?php echo htmlspecialchars($totalmemory['total-memory']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Free Memory - Kb</label>
                        <div class="col-xs-8">
                            <input readonly name="free_memory" class="form-control" value=<?php echo htmlspecialchars($freememory['free-memory']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Total HDD Space - Kb</label>
                        <div class="col-xs-8">
                            <input readonly name="total_hdd_space" class="form-control" value=<?php echo htmlspecialchars($totalhddspace['total-hdd-space']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Free HDD Space - Kb</label>
                        <div class="col-xs-8">
                            <input readonly name="free_hdd_space" class="form-control" value=<?php echo htmlspecialchars($freehddspace['free-hdd-space']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Sector Write Total</label>
                        <div class="col-xs-8">
                            <input readonly name="write_sect_total" class="form-control" value=<?php echo htmlspecialchars( $writesecttotal['write-sect-total']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Sector Write Since Reboot</label>
                        <div class="col-xs-8">
                            <input readonly name="write_sect_since_reboot" class="form-control" value=<?php echo htmlspecialchars($writesectsincereboot['write-sect-since-reboot']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Sector Bad Block</label>
                        <div class="col-xs-8">
                            <input readonly name="bad_blocks" class="form-control" value=<?php echo htmlspecialchars($badblocks['bad-blocks']);?>>
                        </div>
                    </div>



<!-- <<<<<<<<<<<<<<<<<<<<<<<<< INTERFACE 1 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> -->
                     <div class="form-group">
                    <div style="text-align: center;">Interface 1 </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Name</label>
                        <div class="col-xs-8">
                            <input readonly name="name" class="form-control" value=<?php echo htmlspecialchars($nama['name']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Default Name</label>
                        <div class="col-xs-8">
                            <input readonly name="defaultname" class="form-control" value=<?php echo htmlspecialchars($defaultname['default-name']);?>>
                        </div>
                    </div><div class="form-group">
                        <label class="control-label col-xs-3" >Mac Address</label>
                        <div class="col-xs-8">
                            <input readonly name="macaddress" class="form-control" value=<?php echo htmlspecialchars($macaddress['mac-address']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Last Link Down Time</label>
                        <div class="col-xs-8">
                            <input readonly name="lastlinkdowntime" class="form-control" value=<?php echo htmlspecialchars($lastlinkdowntime['last-link-down-time']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Last Link Up Time</label>
                        <div class="col-xs-8">
                            <input readonly name="lastlinkuptime" class="form-control" value=<?php echo htmlspecialchars($lastlinkuptime['last-link-up-time']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Rx byte</label>
                        <div class="col-xs-8">
                            <input readonly name="rxbyte" class="form-control" value=<?php echo htmlspecialchars($rxbyte['rx-byte']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >tx byte</label>
                        <div class="col-xs-8">
                            <input readonly name="txbyte" class="form-control" value=<?php echo htmlspecialchars($txbyte['tx-byte']);?>>
                        </div>
                    </div><div class="form-group">
                        <label class="control-label col-xs-3" >rx packet</label>
                        <div class="col-xs-8">
                            <input readonly name="rxpacket" class="form-control" value=<?php echo htmlspecialchars($rxpacket['rx-packet']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >tx packet</label>
                        <div class="col-xs-8">
                            <input readonly name="txpacket" class="form-control" value=<?php echo htmlspecialchars($txpacket['tx-packet']);?>>
                        </div>
                    </div>



<!-- <<<<<<<<<<<<<<<<<<<<<<< INTERFACE 2 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> -->
                    <div style="text-align: center;">Interface 2 </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Name</label>
                        <div class="col-xs-8">
                            <input readonly name="name1" class="form-control" value=<?php echo htmlspecialchars($nama1['name']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Default Name</label>
                        <div class="col-xs-8">
                            <input readonly name="defaultname1" class="form-control" value=<?php echo htmlspecialchars($defaultname1['default-name']);?>>
                        </div>
                    </div><div class="form-group">
                        <label class="control-label col-xs-3" >Mac Address</label>
                        <div class="col-xs-8">
                            <input readonly name="macaddress1" class="form-control" value=<?php echo htmlspecialchars($macaddress1['mac-address']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Last Link Down Time</label>
                        <div class="col-xs-8">
                            <input readonly name="lastlinkdowntime1" class="form-control" value=<?php echo htmlspecialchars($lastlinkdowntime1['last-link-down-time']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Last Link Up Time</label>
                        <div class="col-xs-8">
                            <input readonly name="lastlinkuptime1" class="form-control" value=<?php echo htmlspecialchars($lastlinkuptime1['last-link-up-time']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Rx byte</label>
                        <div class="col-xs-8">
                            <input readonly name="rxbyte1" class="form-control" value=<?php echo htmlspecialchars($rxbyte1['rx-byte']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >tx byte</label>
                        <div class="col-xs-8">
                            <input readonly name="txbyte1" class="form-control" value=<?php echo htmlspecialchars($txbyte1['tx-byte']);?>>
                        </div>
                    </div><div class="form-group">
                        <label class="control-label col-xs-3" >rx packet</label>
                        <div class="col-xs-8">
                            <input readonly name="rxpacket1" class="form-control" value=<?php echo htmlspecialchars($rxpacket1['rx-packet']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >tx packet</label>
                        <div class="col-xs-8">
                            <input readonly name="txpacket1" class="form-control" value=<?php echo htmlspecialchars($txpacket1['tx-packet']);?>>
                        </div>
                    </div>



<!-- <<<<<<<<<<<<<<<<<<<<<<< INTERFACE 3 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> -->
                    <div style="text-align: center;">Interface 3 </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Name</label>
                        <div class="col-xs-8">
                            <input readonly name="name2" class="form-control" value=<?php echo htmlspecialchars($nama2['name']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Default Name</label>
                        <div class="col-xs-8">
                            <input readonly name="defaultname2" class="form-control" value=<?php echo htmlspecialchars($defaultname2['default-name']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Mac Address</label>
                        <div class="col-xs-8">
                            <input readonly name="macaddress2" class="form-control" value=<?php echo htmlspecialchars($macaddress2['mac-address']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Last Link Down Time</label>
                        <div class="col-xs-8">
                            <input readonly name="lastlinkdowntime2" class="form-control" value="0"><!-- <?php echo htmlspecialchars($lastlinkdowntime2['last-link-down-time']);?> -->
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Last Link Up Time</label>
                        <div class="col-xs-8">
                            <input readonly name="lastlinkuptime2" class="form-control" value="0"><!-- <?php echo htmlspecialchars($lastlinkuptime2['last-link-up-time']);?> -->
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Rx byte</label>
                        <div class="col-xs-8">
                            <input readonly name="rxbyte2" class="form-control" value=<?php echo htmlspecialchars($rxbyte2['rx-byte']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >tx byte</label>
                        <div class="col-xs-8">
                            <input readonly name="txbyte2" class="form-control" value=<?php echo htmlspecialchars($txbyte2['tx-byte']);?>>
                        </div>
                    </div><div class="form-group">
                        <label class="control-label col-xs-3" >rx packet</label>
                        <div class="col-xs-8">
                            <input readonly name="rxpacket2" class="form-control" value=<?php echo htmlspecialchars($rxpacket2['rx-packet']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >tx packet</label>
                        <div class="col-xs-8">
                            <input readonly name="txpacket2" class="form-control" value=<?php echo htmlspecialchars($txpacket2['tx-packet']);?>>
                        </div>
                    </div>



<!-- <<<<<<<<<<<<<<<<<<<<<<< INTERFACE 4 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> -->
                    <div style="text-align: center;">Interface 4 </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Name</label>
                        <div class="col-xs-8">
                            <input readonly name="name3" class="form-control" value=<?php echo htmlspecialchars($nama3['name']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Default Name</label>
                        <div class="col-xs-8">
                            <input readonly name="defaultname3" class="form-control" value=<?php echo htmlspecialchars($defaultname3['default-name']);?>>
                        </div>
                    </div><div class="form-group">
                        <label class="control-label col-xs-3" >Mac Address</label>
                        <div class="col-xs-8">
                            <input readonly name="macaddress3" class="form-control" value=<?php echo htmlspecialchars($macaddress3['mac-address']);?>>
                        </div>
                    </div>
                     <div class="form-group">
                        <label class="control-label col-xs-3" >Last Link Down Time</label>
                        <div class="col-xs-8">
                            <input readonly name="lastlinkdowntime3" class="form-control" value="0"><!-- <?php echo htmlspecialchars($lastlinkdowntime3['last-link-down-time']);?> -->
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Last Link Up Time</label>
                        <div class="col-xs-8">
                            <input readonly name="lastlinkuptime3" class="form-control" value="0"><!-- <?php echo htmlspecialchars($lastlinkuptime3['last-link-up-time']);?> -->
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Rx byte</label>
                        <div class="col-xs-8">
                            <input readonly name="rxbyte3" class="form-control" value=<?php echo htmlspecialchars($rxbyte3['rx-byte']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >tx byte</label>
                        <div class="col-xs-8">
                            <input readonly name="txbyte3" class="form-control" value=<?php echo htmlspecialchars($txbyte3['tx-byte']);?>>
                        </div>
                    </div><div class="form-group">
                        <label class="control-label col-xs-3" >rx packet</label>
                        <div class="col-xs-8">
                            <input readonly name="rxpacket3" class="form-control" value=<?php echo htmlspecialchars($rxpacket3['rx-packet']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >tx packet</label>
                        <div class="col-xs-8">
                            <input readonly name="txpacket3" class="form-control" value=<?php echo htmlspecialchars($txpacket3['tx-packet']);?>>
                        </div>
                    </div>




<!-- <<<<<<<<<<<<<<<<<<<<<<< INTERFACE 5 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> -->
                    <div style="text-align: center;">Interface 5 </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Name</label>
                        <div class="col-xs-8">
                            <input readonly name="name4" class="form-control" value=<?php echo htmlspecialchars($nama4['name']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Default Name</label>
                        <div class="col-xs-8">
                            <input readonly name="defaultname4" class="form-control" value=<?php echo htmlspecialchars($defaultname4['default-name']);?>>
                        </div>
                    </div><div class="form-group">
                        <label class="control-label col-xs-3" >Mac Address</label>
                        <div class="col-xs-8">
                            <input readonly name="macaddress4" class="form-control" value=<?php echo htmlspecialchars($macaddress4['mac-address']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Last Link Down Time</label>
                        <div class="col-xs-8">
                            <input readonly name="lastlinkdowntime4" class="form-control" value="-"><!-- <?php echo htmlspecialchars($lastlinkdowntime4['last-link-down-time']);?> -->
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Last Link Up Time</label>
                        <div class="col-xs-8">
                            <input readonly name="lastlinkuptime4" class="form-control" value="-"><!-- <?php echo htmlspecialchars($lastlinkuptime4['last-link-up-time']);?> -->
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >Rx byte</label>
                        <div class="col-xs-8">
                            <input readonly name="rxbyte4" class="form-control" value=<?php echo htmlspecialchars($rxbyte4['rx-byte']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >tx byte</label>
                        <div class="col-xs-8">
                            <input readonly name="txbyte4" class="form-control" value=<?php echo htmlspecialchars($txbyte4['tx-byte']);?>>
                        </div>
                    </div><div class="form-group">
                        <label class="control-label col-xs-3" >rx packet</label>
                        <div class="col-xs-8">
                            <input readonly name="rxpacket4" class="form-control" value=<?php echo htmlspecialchars($rxpacket4['rx-packet']);?>>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-xs-3" >tx packet</label>
                        <div class="col-xs-8">
                            <input readonly name="txpacket4" class="form-control" value=<?php echo htmlspecialchars($txpacket4['tx-packet']);?>>
                        </div>
                    </div>
                </div>
                    <!-- 
                <div class="modal-footer">
                    <button class="btn btn-info">Simpan</button>
                </div> -->
            </form>
            </div>
            </div>
        </div>
        <!--END MODAL ADD ADMIN-->
<script src="<?php echo base_url().'assets/js/jquery-2.2.4.min.js'?>"></script>
<script src="<?php echo base_url().'assets/js/bootstrap.js'?>"></script>
<script src="<?php echo base_url().'assets/js/jquery.dataTables.min.js'?>"></script>
<script src="<?php echo base_url().'assets/js/moment.js'?>"></script>
<script>
  $(document).ready(function(){
    $('#mydata').DataTable();
  });
</script>
 </body>
 </html>
<?php ini_set('display_errors','off'); ?>    
