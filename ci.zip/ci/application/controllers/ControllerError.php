<?php 
defined('BASEPATH') or exit('no direct script allowed');
/**
 * 
 */
class ControllerError extends CI_Controller
{
	public function index() {
		echo "URL ERROR";
		/*$this->load->view('masuk');
*/	}

	
}
 ?>