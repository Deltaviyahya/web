<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct()
	{
		# code...
		parent::__construct();
		$this->load->model('login_model');
	}
	function index()
	{
		# code...
		$this->load->view('v_login');
	}

	public function auth()
	{
		$username=htmlspecialchars($this->input->post('username',TRUE),ENT_QUOTES);
		$password=htmlspecialchars($this->input->post('password',TRUE),ENT_QUOTES);

		$cek_admin=$this->login_model->auth_admin($username,$password);

		 if($cek_admin->num_rows() > 0){ 
						$data=$cek_admin->row_array();
        		$this->session->set_userdata('masuk',TRUE);
		         if($data['level']=='1'){ //Akses admin
		            $this->session->set_userdata('akses','1');
		            $this->session->set_userdata('ses_id',$data['nip']);
		            $this->session->set_userdata('ses_nama',$data['nama']);
		            redirect('page');
		         }else{
		         	$this->session->set_userdata('akses','2');
					$this->session->set_userdata('ses_id',$data['nip']);
		            $this->session->set_userdata('ses_nama',$data['nama']);
		            redirect('page');
		        }
        }else{
        	$url=base_url();
					echo $this->session->set_flashdata('msg','Username Atau Password Salah');
					redirect($url);
        }

    }

    function logout(){
        $this->session->sess_destroy();
        $url=base_url('');
        redirect($url);
    }

}

/* End of file login.php */
/* Location: ./application/controllers/login.php */