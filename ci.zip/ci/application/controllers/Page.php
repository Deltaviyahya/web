<?php
class Page extends CI_Controller{
  function __construct(){
    parent::__construct();
    //validasi jika user belum login
    date_default_timezone_set('Asia/Jakarta');
    if($this->session->userdata('masuk') != TRUE){
			$url=base_url();
			redirect($url);
		}
  }

  function index(){
    $this->load->view('home');
  }
  function v_monitoring(){ // fungsi admin
    if($this->session->userdata('akses')=='1' || $this->session->userdata('akses')=='2'){
      $this->load->view('v_monitoring');
    }else{
      echo "Anda tidak berhak mengakses halaman ini";
    }
  }
  function v_server() // fungsi subadmin
  {
    # code...
     if($this->session->userdata('akses')=='1'){
      $this->load->view('v_server');
    }else{
      echo "Anda tidak berhak mengakses halaman ini";
    }
  }
  function v_listadmin() // fungsi subadmin
  {
    # code...
    if($this->session->userdata('akses')=='1'){
      $this->load->view('v_listadmin');
    }else{
      echo "Anda tidak berhak mengakses halaman ini";
    }
  }
}

