<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_monitoring extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('monitoring_model');
		$this->load->helper('url');
	}

	public function index()
	{
		$y['datarouter']=$this->monitoring_model->show_datarouter()->result();
		$this->load->view('v_monitoring',$y);
	}

		# code...
		
	
}


/* End of file C_monitoring.php */
/* Location: ./application/controllers/C_monitoring.php */