<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_admin extends CI_Controller {

	function __construct(){
		parent::__construct();
		date_default_timezone_set('Asia/Jakarta');
		$this->load->model('admin_model');
		$this->load->helper('url');
	}

	public function index()
	{
		$x['listadmin']=$this->admin_model->show_admin();
		$this->load->view('v_listadmin',$x);
	}
	function simpan_admin(){
        $nip=$this->input->post('nip');
        $nama=$this->input->post('nama');
        $pass=$this->input->post('pass');
        $level=$this->input->post('level');
        $this->admin_model->simpan_admin($nip,$nama,$pass,$level);
        redirect('listadmin');
    }
     function edit_admin(){
        $nip=$this->input->post('nip');
        $nama=$this->input->post('nama');
        $pass=$this->input->post('pass');
        $level=$this->input->post('level');
        $this->admin_model->edit_admin($nip,$nama,$pass,$level);
        redirect('listadmin');
    }
    function hapus_admin(){
        $nip=$this->input->post('nip');
        $this->admin_model->hapus_admin($nip);
        redirect('listadmin');
    }
	
}

/* End of file Admin_C.php */
/* Location: ./application/controllers/Admin_C.php */