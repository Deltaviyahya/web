<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Server extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('Server_model');
		$this->load->helper('url');
	}

	public function index()
	{
		$this->load->view('v_server');
	}
	function simpan_data_device(){
			//device
		 	$platform		=$this->input->post('platform');
		 	$boardname	=$this->input->post('board_name');
		 	$version		=$this->input->post('version');
		 	$architecturename=$this->input->post('architecture_name');
		 	$cpu			=$this->input->post('cpu');
		 	$cpufrequency	=$this->input->post('cpu_frequency');
		 	$cpucount	=$this->input->post('cpu_count');
		 	$uptime		=$this->input->post('uptime');
		 	$cpuload		=$this->input->post('cpu_load');
		 	$totalmemory	=$this->input->post('total_memory');
		 	$freememory	=$this->input->post('free_memory');
		 	$totalhddspace=$this->input->post('total_hdd_space');
		 	$freehddspace	=$this->input->post('free_hdd_space');
		 	$writesecttotal=$this->input->post('write_sect_total');
		 	$writesectsincereboot=$this->input->post('write_sect_since_reboot');
		 	$badblocks	=$this->input->post('bad_blocks');
		 	$this->Server_model->simpan_data_device(
		 		//device
		 		$platform,$boardname,$version,$architecturename,$cpu,$cpufrequency,$cpucount,$uptime,$cpuload,$totalmemory,$freememory,$totalhddspace,$freehddspace,$writesecttotal,$writesectsincereboot,$badblocks
		 		);
		 	redirect('server','refresh');
	}
	function simpan_data_interface()
	{
		# code...
		 	$name =$this->input->post('name');
            $defaultname =$this->input->post('defaultname');
            $macaddress =$this->input->post('macaddress');
            $lastlinkdowntime =$this->input->post('lastlinkdowntime');
            $lastlinkuptime =$this->input->post('lastlinkuptime');
            $rxbyte =$this->input->post('rxbyte');
            $txbyte =$this->input->post('txbyte');
            $rxpacket =$this->input->post('rxpacket');
            $txpacket =$this->input->post('txpacket');

            $name1 =$this->input->post('name');
            $defaultname1 =$this->input->post('defaultname');
            $macaddress1 =$this->input->post('macaddress');
            $lastlinkdowntime1 =$this->input->post('lastlinkdowntime');
            $lastlinkuptime1 =$this->input->post('lastlinkuptime');
            $rxbyte1 =$this->input->post('rxbyte');
            $txbyte1 =$this->input->post('txbyte');
            $rxpacket1 =$this->input->post('rxpacket');
            $txpacket1 =$this->input->post('txpacket');

            $name2 =$this->input->post('name');
            $defaultname2 =$this->input->post('defaultname');
            $macaddress2 =$this->input->post('macaddress');
            $lastlinkdowntime2 =$this->input->post('lastlinkdowntime');
            $lastlinkuptime2 =$this->input->post('lastlinkuptime');
            $rxbyte2 =$this->input->post('rxbyte');
            $txbyte2 =$this->input->post('txbyte');
            $rxpacket2 =$this->input->post('rxpacket');
            $txpacket2 =$this->input->post('txpacket');

            $name3 =$this->input->post('name');
            $defaultname3 =$this->input->post('defaultname');
            $macaddress3 =$this->input->post('macaddress');
            $lastlinkdowntime3 =$this->input->post('lastlinkdowntime');
            $lastlinkuptime3 =$this->input->post('lastlinkuptime');
            $rxbyte3 =$this->input->post('rxbyte');
            $txbyte3 =$this->input->post('txbyte');
            $rxpacket3 =$this->input->post('rxpacket');
            $txpacket3 =$this->input->post('txpacket');

            $name4 =$this->input->post('name');
            $defaultname4 =$this->input->post('defaultname');
            $macaddress4 =$this->input->post('macaddress');
            $lastlinkdowntime4 =$this->input->post('lastlinkdowntime');
            $lastlinkuptime4 =$this->input->post('lastlinkuptime');
            $rxbyte4 =$this->input->post('rxbyte');
            $txbyte4 =$this->input->post('txbyte');
            $rxpacket4 =$this->input->post('rxpacket');
            $txpacket4 =$this->input->post('txpacket');
            $this->Server_model->simpan_data_interface(
            	$name,$defaultname,$macaddress,$lastlinkdowntime,$lastlinkuptime,$rxbyte,$txbyte,$rxpacket,$txpacket,
				$name1,$defaultname1,$macaddress1,$lastlinkdowntime1,$lastlinkuptime1,$rxbyte1,$txbyte1,$rxpacket1,$txpacket1,
				$name2,$defaultname2,$macaddress2,$lastlinkdowntime2,$lastlinkuptime2,$rxbyte2,$txbyte2,$rxpacket2,$txpacket2,
				$name3,$defaultname3,$macaddress3,$lastlinkdowntime3,$lastlinkuptime3,$rxbyte3,$txbyte3,$rxpacket3,$txpacket3,
				$name4,$defaultname4,$macaddress4,$lastlinkdowntime4,$lastlinkuptime4,$rxbyte4,$txbyte4,$rxpacket4,$txpacket4);
            redirect('server','refresh');
	}
	function update_device()
	{
			//device
		 	$platform		=$this->input->post('platform');
		 	$boardname	=$this->input->post('board_name');
		 	$version		=$this->input->post('version');
		 	$architecturename=$this->input->post('architecture_name');
		 	$cpu			=$this->input->post('cpu');
		 	$cpufrequency	=$this->input->post('cpu_frequency');
		 	$cpucount	=$this->input->post('cpu_count');
		 	$uptime		=$this->input->post('uptime');
		 	$cpuload		=$this->input->post('cpu_load');
		 	$totalmemory	=$this->input->post('total_memory');
		 	$freememory	=$this->input->post('free_memory');
		 	$totalhddspace=$this->input->post('total_hdd_space');
		 	$freehddspace	=$this->input->post('free_hdd_space');
		 	$writesecttotal=$this->input->post('write_sect_total');
		 	$writesectsincereboot=$this->input->post('write_sect_since_reboot');
		 	$badblocks	=$this->input->post('bad_blocks');
		 	
		 	
		 	$this->Server_model->update_device(
		 		//device
		 		$platform,$boardname,$version,$architecturename,$cpu,$cpufrequency,$cpucount,$uptime,$cpuload,$totalmemory,$freememory,$totalhddspace,$freehddspace,$writesecttotal,$writesectsincereboot,$badblocks);
		 	redirect('server','refresh');
	}
      function update_interface(){

            //interface1
            $name =$this->input->post('name');
            $defaultname =$this->input->post('defaultname');
            $macaddress =$this->input->post('macaddress');
            $lastlinkdowntime =$this->input->post('lastlinkdowntime');
            $lastlinkuptime =$this->input->post('lastlinkuptime');
            $rxbyte =$this->input->post('rxbyte');
            $txbyte =$this->input->post('txbyte');
            $rxpacket =$this->input->post('rxpacket');
            $txpacket =$this->input->post('txpacket');

            //interface 2

            $name1 =$this->input->post('name');
            $defaultname1 =$this->input->post('defaultname');
            $macaddress1 =$this->input->post('macaddress');
            $lastlinkdowntime1 =$this->input->post('lastlinkdowntime');
            $lastlinkuptime1 =$this->input->post('lastlinkuptime');
            $rxbyte1 =$this->input->post('rxbyte');
            $txbyte1 =$this->input->post('txbyte');
            $rxpacket1 =$this->input->post('rxpacket');
            $txpacket1 =$this->input->post('txpacket');

            /// interface 3

            $name2 =$this->input->post('name');
            $defaultname2 =$this->input->post('defaultname');
            $macaddress2 =$this->input->post('macaddress');
            $lastlinkdowntime2 =$this->input->post('lastlinkdowntime');
            $lastlinkuptime2 =$this->input->post('lastlinkuptime');
            $rxbyte2 =$this->input->post('rxbyte');
            $txbyte2 =$this->input->post('txbyte');
            $rxpacket2 =$this->input->post('rxpacket');
            $txpacket2 =$this->input->post('txpacket');

            // interface 4

            $name3 =$this->input->post('name');
            $defaultname3 =$this->input->post('defaultname');
            $macaddress3 =$this->input->post('macaddress');
            $lastlinkdowntime3 =$this->input->post('lastlinkdowntime');
            $lastlinkuptime3 =$this->input->post('lastlinkuptime');
            $rxbyte3 =$this->input->post('rxbyte');
            $txbyte3 =$this->input->post('txbyte');
            $rxpacket3 =$this->input->post('rxpacket');
            $txpacket3 =$this->input->post('txpacket');

            //interface 5

            $name4 =$this->input->post('name');
            $defaultname4 =$this->input->post('defaultname');
            $macaddress4 =$this->input->post('macaddress');
            $lastlinkdowntime4 =$this->input->post('lastlinkdowntime');
            $lastlinkuptime4 =$this->input->post('lastlinkuptime');
            $rxbyte4 =$this->input->post('rxbyte');
            $txbyte4 =$this->input->post('txbyte');
            $rxpacket4 =$this->input->post('rxpacket');
            $txpacket4 =$this->input->post('txpacket');

            $this->Server_model->update_interface(
            //interface
                        $name,$defaultname,$macaddress,$lastlinkdowntime,$lastlinkuptime,$rxbyte,$txbyte,$rxpacket,$txpacket,
                        $name1,$defaultname1,$macaddress1,$lastlinkdowntime1,$lastlinkuptime1,$rxbyte1,$txbyte1,$rxpacket1,$txpacket1,
                        $name2,$defaultname2,$macaddress2,$lastlinkdowntime2,$lastlinkuptime2,$rxbyte2,$txbyte2,$rxpacket2,$txpacket2,
                        $name3,$defaultname3,$macaddress3,$lastlinkdowntime3,$lastlinkuptime3,$rxbyte3,$txbyte3,$rxpacket3,$txpacket3,
                        $name4,$defaultname4,$macaddress4,$lastlinkdowntime4,$lastlinkuptime4,$rxbyte4,$txbyte4,$rxpacket4,$txpacket4);
            redirect('server','refresh');
      }
      function update(){
            $this->update_device();
            $this->update_interface();
      }

}

/* End of file Server.php */
/* Location: ./application/controllers/Server.php */