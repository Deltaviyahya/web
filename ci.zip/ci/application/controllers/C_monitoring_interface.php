<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_monitoring_interface extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('monitoring_model');
		$this->load->helper('url');
	}

	public function index()
	{
		$x['datainterface']=$this->monitoring_model->show_datainterface()->result_array();
		$this->load->view('v_monitoringinterface',$x);
	}

}

/* End of file C_monitoring_interface.php */
/* Location: ./application/controllers/C_monitoring_interface.php */