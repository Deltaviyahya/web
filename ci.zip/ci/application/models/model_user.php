<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_user extends CI_Model {

	function login($username,$password)
	{
		# code...
		$auth = $this->db->get_where('user', array('username' =>$username ,'password' =>$password ));
		if ($auth->num_row()>0) {
			# code...
			return 1;
		}else{
			return 0;
		}
	}

}

/* End of file model_user.php */
/* Location: ./application/models/model_user.php */