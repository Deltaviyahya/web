<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Server_model extends CI_Model {

	function __construct(){
        parent::__construct();
    }


	function simpan_data_device(
		$platform,$boardname,$version,$architecturename,$cpu,$cpufrequency,$cpucount,$uptime,$cpuload,$totalmemory,$freememory,$totalhddspace,$freehddspace,$writesecttotal,$writesectsincereboot,$badblocks)
	{
		# code...
		$hasil=$this->db->query("
			INSERT INTO datarouter (
			platform,
			board_name,
			version,
			architecture_name,
			cpu,
			cpu_frequency,
			cpu_count,
			uptime,
			cpu_load,
			total_memory,
			free_memory,
			total_hdd_space,
			free_hdd_space,
			write_sect_total,
			write_sect_since_reboot,
			bad_blocks
			) 
			VALUES (
			'$platform',
			'$boardname',
			'$version',
			'$architecturename',
			'$cpu',
			'$cpufrequency',
			'$cpucount',
			'$uptime',
			'$cpuload',
			'$totalmemory',
			'$freememory',
			'$totalhddspace',
			'$freehddspace',
			'$writesecttotal',
			'$writesectsincereboot',
			'$badblocks')");
		return $hasil;

	}
	function simpan_data_interface(
		$name,$defaultname,$macaddress,$lastlinkdowntime,$lastlinkuptime,$rxbyte,$txbyte,$rxpacket,$txpacket,
		$name1,$defaultname1,$macaddress1,$lastlinkdowntime1,$lastlinkuptime1,$rxbyte1,$txbyte1,$rxpacket1,$txpacket1,
		$name2,$defaultname2,$macaddress2,$lastlinkdowntime2,$lastlinkuptime2,$rxbyte2,$txbyte2,$rxpacket2,$txpacket2,
		$name3,$defaultname3,$macaddress3,$lastlinkdowntime3,$lastlinkuptime3,$rxbyte3,$txbyte3,$rxpacket3,$txpacket3,
		$name4,$defaultname4,$macaddress4,$lastlinkdowntime4,$lastlinkuptime4,$rxbyte4,$txbyte4,$rxpacket4,$txpacket4)
	{
		# code...
		$hasil6=$this->db->query(
			"INSERT INTO interface(
			name,
			defaultname,
			macaddress,
			lastlinkdowntime,
			lastlinkuptime,
			rxbyte,
			txbyte,
			rxpacket,
			txpacket)
			VALUES(
			'$name','$defaultname','$macaddress','$lastlinkdowntime','$lastlinkuptime','$rxbyte','$txbyte','$rxpacket','$txpacket',
			'$name1','$defaultname1','$macaddress1','$lastlinkdowntime1','$lastlinkuptime1','$rxbyte1','$txbyte1','$rxpacket1','$txpacket1',
			'$name2','$defaultname2','$macaddress2','$lastlinkdowntime2','$lastlinkuptime2','$rxbyte2','$txbyte2','$rxpacket2','$txpacket2',
			'$name3','$defaultname3','$macaddress3','$lastlinkdowntime3','$lastlinkuptime3','$rxbyte3','$txbyte3','$rxpacket3','$txpacket3',
			'$name4','$defaultname4','$macaddress4','$lastlinkdowntime3','$lastlinkuptime3','$rxbyte4','$txbyte4','$rxpacket4','$txpacket4')");
		return $hasil6;
	}
	function update_device(
		//device
		$platform,$boardname,$version,$architecturename,$cpu,$cpufrequency,$cpucount,$uptime,$cpuload,$totalmemory,$freememory,$totalhddspace,$freehddspace,$writesecttotal,$writesectsincereboot,$badblocks)

	{
		# code...
		$hasil=$this->db->query("UPDATE datarouter SET 
			platform='$platform',
			board_name='$boardname',
			version='$version',
			architecture_name='$architecturename',
			cpu='$cpu',
			cpu_frequency='$cpufrequency',
			cpu_count='$cpucount',
			uptime='$uptime',
			cpu_load='$cpuload',
			total_memory='$totalmemory',
			free_memory='$freememory',
			total_hdd_space='$totalhddspace',
			free_hdd_space='$freehddspace',
			write_sect_total='$writesecttotal',
			write_sect_since_reboot='$writesectsincereboot',
			bad_blocks='$badblocks'
			WHERE id=1");
		return $hasil;
		
	}
	function update_interface(
		$name,$defaultname,$macaddress,$lastlinkdowntime,$lastlinkuptime,$rxbyte,$txbyte,$rxpacket,$txpacket,
		$name1,$defaultname1,$macaddress1,$lastlinkdowntime1,$lastlinkuptime1,$rxbyte1,$txbyte1,$rxpacket1,$txpacket1,
		$name2,$defaultname2,$macaddress2,$lastlinkdowntime2,$lastlinkuptime2,$rxbyte2,$txbyte2,$rxpacket2,$txpacket2,
		$name3,$defaultname3,$macaddress3,$lastlinkdowntime3,$lastlinkuptime3,$rxbyte3,$txbyte3,$rxpacket3,$txpacket3,
		$name4,$defaultname4,$macaddress4,$lastlinkdowntime4,$lastlinkuptime4,$rxbyte4,$txbyte4,$rxpacket4,$txpacket4){
		$hasil1=$this->db->query("UPDATE interface SET 
			name='$name',
			defaultname='$defaultname',
			macaddress='$macaddress',
			lastlinkdowntime='$lastlinkdowntime',
			lastlinkuptime='$lastlinkuptime',
			rxbyte='$rxbyte',
			txbyte=	'$txbyte',
			rxpacket=	'$rxpacket',
			txpacket=	'$txpacket'  
			WHERE id=1");
		return $this->db->insert_id();;
		$hasil2=$this->db->query("UPDATE nterface SET 
			name='$name1',
			defaultname='$defaultname1',
			macaddress='$macaddress1',
			lastlinkdowntime='$lastlinkdowntime1',
			lastlinkuptime='$lastlinkuptime1',
			rxbyte='$rxbyte1',
			txbyte=	'$txbyte1',
			rxpacket=	'$rxpacket1',
			txpacket=	'$txpacket1'  
			WHERE id=2");
		return $hasil2;
		$hasil3=$this->db->query("UPDATE interface SET 
			name='$name2',
			defaultname='$defaultname2',
			macaddress='$macaddress2',
			lastlinkdowntime='$lastlinkdowntime2',
			lastlinkuptime='$lastlinkuptime2',
			rxbyte='$rxbyte2',
			txbyte=	'$txbyte2',
			rxpacket=	'$rxpacket2',
			txpacket=	'$txpacket2'  
			WHERE id=3");
		return $hasil3;
		$hasil4=$this->db->query("UPDATE interface SET 
			name='$name3',
			defaultname='$defaultname3',
			macaddress='$macaddress3',
			lastlinkdowntime='$lastlinkdowntime3',
			lastlinkuptime='$lastlinkuptime3',
			rxbyte='$rxbyte3',
			txbyte=	'$txbyte3',
			rxpacket=	'$rxpacket3',
			txpacket=	'$txpacket3'  
			WHERE id=4");
		return $hasil4;
		$hasil5=$this->db->query("UPDATE interface SET 
			name='$name4',
			defaultname='$defaultname4',
			macaddress='$macaddress4',
			lastlinkdowntime='$lastlinkdowntime4',
			lastlinkuptime='$lastlinkuptime4',
			rxbyte='$rxbyte4',
			txbyte=	'$txbyte4',
			rxpacket=	'$rxpacket4',
			txpacket=	'$txpacket4'  
			WHERE id=5");
		return $hasil5;

	}

}

/* End of file Server_model.php */
/* Location: ./application/models/Server_model.php */