<?php
class Login_model extends CI_Model{
	//cek nip dan password admin
	function auth_admin($username,$password){
		$query=$this->db->query("SELECT * FROM admin WHERE nip='$username' AND pass='$password' LIMIT 1");
		return $query;
	}

}
