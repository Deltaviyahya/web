<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model {

	function show_admin()
	{
		# code...
		$hasil = $this->db->get('admin');
		return $hasil;
	}
	function simpan_admin($nip,$nama,$pass,$level){
        $hasil=$this->db->query("INSERT INTO admin (nip,nama,pass,level) VALUES ('$nip','$nama','$pass','$level')");
        return $hasil;
    }
	function edit_admin($nip,$nama,$pass,$level){
        $hasil=$this->db->query("UPDATE admin SET nip='$nip',nama='$nama',pass='$pass',level='$level' WHERE nip='$nip'");
        return $hasil;
    }
     function hapus_admin($nip){
        $hasil=$this->db->query("DELETE FROM admin WHERE nip='$nip'");
        return $hasil;
    }
}

/* End of file Admin_model.php */
/* Location: ./application/models/Admin_model.php */