<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Monitoring_model extends CI_Model {

	function show_datarouter()
	{
		# code...
		$hasil = $this->db->get('datarouter');
		return $hasil;
	}
	function show_datainterface(){
		$hasil1 = $this->db->get('interface');
		return $hasil1;
	}

}